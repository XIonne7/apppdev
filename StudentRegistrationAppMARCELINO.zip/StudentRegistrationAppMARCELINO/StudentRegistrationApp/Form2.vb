﻿Public Class Form2


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnText.Click

        Dim sttxtName As String
        Dim sttxtAge As String
        Dim sttxtEmail As String

        sttxtName = txtName.Text
        sttxtAge = txtAge.Text
        sttxtEmail = txtEmail.Text


        cmbGender.Items.Add("Male")
        cmbGender.Items.Add("Female")
        cmbGender.Items.Add("Other")

        cmbCourse.Items.Add("Mathematics")
        cmbCourse.Items.Add("Science")
        cmbCourse.Items.Add("History")



        If txtName.Text = "Charles" And txtAge.Text = "20" And txtEmail.Text = "charles@gmail.com" Then
            MsgBox("You Registered successfully")
            MsgBox("Your name is " & sttxtName & " " & sttxtAge & " years old" & " and your Email is " & sttxtEmail & " .your gender is " & cmbGender.Text & " and your favourite subject is " & cmbCourse.Text)

        Else
            MsgBox("You Failed Miserable")
        End If



    End Sub


End Class